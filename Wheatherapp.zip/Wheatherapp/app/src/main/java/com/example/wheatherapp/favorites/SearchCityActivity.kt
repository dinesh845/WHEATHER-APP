package com.example.wheatherapp.favorites

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wheatherapp.adapter.CitySearchAdapter
import com.example.wheatherapp.dashboard.MainActivity
import com.example.wheatherapp.databinding.ActivitySearchCityBinding
import com.example.wheatherapp.model.FavoriteCity
import com.example.wheatherapp.network.RetrofitClient
import kotlinx.coroutines.launch

class SearchCityActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchCityBinding
    private lateinit var favoritesManager: FavoritesManager
    private lateinit var adapter: CitySearchAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchCityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        favoritesManager = FavoritesManager(this)

        binding.btnBack.setOnClickListener { finish() }

        setupRecyclerView()

        binding.btnSearchSubmit.setOnClickListener {
            performSearch()
        }

        binding.etSearchQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                true
            } else {
                false
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = CitySearchAdapter(
            results = emptyList(),
            onAddFavoriteClick = { cityResult ->
                val favCity = FavoriteCity(
                    id = cityResult.id.toString(),
                    name = cityResult.name,
                    country = cityResult.country,
                    latitude = cityResult.latitude,
                    longitude = cityResult.longitude
                )
                favoritesManager.addFavorite(favCity)
                Toast.makeText(this, "${cityResult.name} added to Favorites", Toast.LENGTH_SHORT).show()
            },
            onItemClick = { cityResult ->
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_LAT, cityResult.latitude)
                    putExtra(MainActivity.EXTRA_LON, cityResult.longitude)
                    putExtra(MainActivity.EXTRA_CITY_NAME, cityResult.name)
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
                finish()
            }
        )
        binding.rvSearchResults.layoutManager = LinearLayoutManager(this)
        binding.rvSearchResults.adapter = adapter
    }

    private fun performSearch() {
        val query = binding.etSearchQuery.text?.toString()?.trim() ?: ""
        if (query.isEmpty()) {
            binding.etSearchQuery.error = "Enter city name to search"
            return
        }

        binding.searchProgressBar.visibility = View.VISIBLE
        binding.tvNoResults.visibility = View.GONE

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.searchCities(name = query)
                binding.searchProgressBar.visibility = View.GONE
                val results = response.results ?: emptyList()

                if (results.isEmpty()) {
                    binding.tvNoResults.visibility = View.VISIBLE
                    adapter.updateData(emptyList())
                } else {
                    binding.tvNoResults.visibility = View.GONE
                    adapter.updateData(results)
                }
            } catch (e: Exception) {
                binding.searchProgressBar.visibility = View.GONE
                Toast.makeText(this@SearchCityActivity, "Search failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}