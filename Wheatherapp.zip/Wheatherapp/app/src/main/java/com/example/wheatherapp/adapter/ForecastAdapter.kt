package com.example.wheatherapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.wheatherapp.R
import com.example.wheatherapp.model.DailyForecastItem
import com.example.wheatherapp.utils.TemperatureUtils

class ForecastAdapter(
    private var items: List<DailyForecastItem>,
    private var isCelsius: Boolean
) : RecyclerView.Adapter<ForecastAdapter.ForecastViewHolder>() {

    class ForecastViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDayName: TextView = itemView.findViewById(R.id.tvDayName)
        val ivWeatherIcon: ImageView = itemView.findViewById(R.id.ivWeatherIcon)
        val tvMaxTemp: TextView = itemView.findViewById(R.id.tvMaxTemp)
        val tvMinTemp: TextView = itemView.findViewById(R.id.tvMinTemp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForecastViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_forecast_day, parent, false)
        return ForecastViewHolder(view)
    }

    override fun onBindViewHolder(holder: ForecastViewHolder, position: Int) {
        val item = items[position]
        holder.tvDayName.text = item.dayName
        holder.ivWeatherIcon.setImageResource(item.iconResId)
        holder.tvMaxTemp.text = TemperatureUtils.formatTemperature(item.maxTempC, isCelsius)
        holder.tvMinTemp.text = TemperatureUtils.formatTemperature(item.minTempC, isCelsius)
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<DailyForecastItem>, newIsCelsius: Boolean) {
        this.items = newItems
        this.isCelsius = newIsCelsius
        notifyDataSetChanged()
    }
}