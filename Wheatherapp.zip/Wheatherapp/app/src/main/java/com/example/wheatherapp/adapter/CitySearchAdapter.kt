package com.example.wheatherapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.wheatherapp.R
import com.example.wheatherapp.model.GeocodingResult
import com.google.android.material.button.MaterialButton

class CitySearchAdapter(
    private var results: List<GeocodingResult>,
    private val onAddFavoriteClick: (GeocodingResult) -> Unit,
    private val onItemClick: (GeocodingResult) -> Unit
) : RecyclerView.Adapter<CitySearchAdapter.SearchViewHolder>() {

    class SearchViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCityName: TextView = itemView.findViewById(R.id.tvCityName)
        val tvRegionCountry: TextView = itemView.findViewById(R.id.tvRegionCountry)
        val btnAddFavorite: MaterialButton = itemView.findViewById(R.id.btnAddFavorite)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_city_search, parent, false)
        return SearchViewHolder(view)
    }

    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        val result = results[position]
        holder.tvCityName.text = result.name

        val regionText = listOfNotNull(result.admin1, result.country).joinToString(", ")
        holder.tvRegionCountry.text = if (regionText.isNotEmpty()) regionText else "Unknown Region"

        holder.itemView.setOnClickListener { onItemClick(result) }
        holder.btnAddFavorite.setOnClickListener { onAddFavoriteClick(result) }
    }

    override fun getItemCount(): Int = results.size

    fun updateData(newResults: List<GeocodingResult>) {
        this.results = newResults
        notifyDataSetChanged()
    }
}