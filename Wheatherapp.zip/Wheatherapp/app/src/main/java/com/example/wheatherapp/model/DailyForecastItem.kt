package com.example.wheatherapp.model

data class DailyForecastItem(
    val dayName: String,
    val dateString: String,
    val maxTempC: Double,
    val minTempC: Double,
    val weatherCode: Int,
    val conditionDescription: String,
    val iconResId: Int
)