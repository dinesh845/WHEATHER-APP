package com.example.wheatherapp.settings

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    var isCelsius: Boolean
        get() = prefs.getBoolean(KEY_IS_CELSIUS, true)
        set(value) {
            prefs.edit().putBoolean(KEY_IS_CELSIUS, value).apply()
        }

    companion object {
        private const val PREF_NAME = "weather_settings_pref"
        private const val KEY_IS_CELSIUS = "key_is_celsius"
    }
}