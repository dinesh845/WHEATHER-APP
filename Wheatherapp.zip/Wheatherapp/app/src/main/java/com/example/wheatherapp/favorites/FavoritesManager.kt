package com.example.wheatherapp.favorites

import android.content.Context
import android.content.SharedPreferences
import com.example.wheatherapp.model.FavoriteCity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.math.abs

class FavoritesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getFavorites(): List<FavoriteCity> {
        val json = prefs.getString(KEY_FAVORITES, null) ?: return emptyList()
        val type = object : TypeToken<List<FavoriteCity>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun addFavorite(city: FavoriteCity) {
        val list = getFavorites().toMutableList()
        if (list.none { it.id == city.id || (abs(it.latitude - city.latitude) < 0.01 && abs(it.longitude - city.longitude) < 0.01) }) {
            list.add(city)
            saveFavorites(list)
        }
    }

    fun removeFavorite(cityId: String) {
        val list = getFavorites().filterNot { it.id == cityId }
        saveFavorites(list)
    }

    fun isFavorite(latitude: Double, longitude: Double): Boolean {
        return getFavorites().any { abs(it.latitude - latitude) < 0.01 && abs(it.longitude - longitude) < 0.01 }
    }

    private fun saveFavorites(list: List<FavoriteCity>) {
        val json = gson.toJson(list)
        prefs.edit().putString(KEY_FAVORITES, json).apply()
    }

    companion object {
        private const val PREF_NAME = "weather_favorites_pref"
        private const val KEY_FAVORITES = "key_favorite_cities"
    }
}