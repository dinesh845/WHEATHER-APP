package com.example.wheatherapp.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wheatherapp.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settingsManager: SettingsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingsManager = SettingsManager(this)

        if (settingsManager.isCelsius) {
            binding.rbCelsius.isChecked = true
        } else {
            binding.rbFahrenheit.isChecked = true
        }

        binding.rgTempUnit.setOnCheckedChangeListener { _, checkedId ->
            settingsManager.isCelsius = (checkedId == binding.rbCelsius.id)
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}