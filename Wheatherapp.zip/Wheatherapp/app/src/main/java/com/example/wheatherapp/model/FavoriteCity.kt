package com.example.wheatherapp.model

data class FavoriteCity(
    val id: String,
    val name: String,
    val country: String?,
    val latitude: Double,
    val longitude: Double
)