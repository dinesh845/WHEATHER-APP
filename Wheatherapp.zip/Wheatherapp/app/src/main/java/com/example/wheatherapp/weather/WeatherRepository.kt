package com.example.wheatherapp.weather

import android.content.Context
import android.content.SharedPreferences
import com.example.wheatherapp.model.WeatherResponse
import com.example.wheatherapp.network.RetrofitClient
import com.google.gson.Gson

class WeatherRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    suspend fun fetchWeather(latitude: Double, longitude: Double): WeatherResponse {
        val response = RetrofitClient.apiService.getWeatherForecast(
            latitude = latitude,
            longitude = longitude
        )
        cacheWeather(response, latitude, longitude)
        return response
    }

    private fun cacheWeather(weather: WeatherResponse, lat: Double, lon: Double) {
        val json = gson.toJson(weather)
        prefs.edit()
            .putString(KEY_CACHED_WEATHER, json)
            .putFloat(KEY_CACHED_LAT, lat.toFloat())
            .putFloat(KEY_CACHED_LON, lon.toFloat())
            .putLong(KEY_CACHE_TIME, System.currentTimeMillis())
            .apply()
    }

    fun getCachedWeather(): WeatherResponse? {
        val json = prefs.getString(KEY_CACHED_WEATHER, null) ?: return null
        return try {
            gson.fromJson(json, WeatherResponse::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun saveCachedCityName(cityName: String) {
        prefs.edit().putString(KEY_CACHED_CITY_NAME, cityName).apply()
    }

    fun getCachedCityName(): String {
        return prefs.getString(KEY_CACHED_CITY_NAME, "Current Location") ?: "Current Location"
    }

    companion object {
        private const val PREF_NAME = "weather_cache_pref"
        private const val KEY_CACHED_WEATHER = "key_cached_weather_json"
        private const val KEY_CACHED_LAT = "key_cached_lat"
        private const val KEY_CACHED_LON = "key_cached_lon"
        private const val KEY_CACHE_TIME = "key_cache_time"
        private const val KEY_CACHED_CITY_NAME = "key_cached_city_name"
    }
}