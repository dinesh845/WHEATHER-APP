package com.example.wheatherapp.favorites

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wheatherapp.adapter.FavoritesAdapter
import com.example.wheatherapp.dashboard.MainActivity
import com.example.wheatherapp.databinding.ActivityFavoritesBinding
import com.example.wheatherapp.model.FavoriteCity

class FavoritesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritesBinding
    private lateinit var favoritesManager: FavoritesManager
    private lateinit var adapter: FavoritesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        favoritesManager = FavoritesManager(this)

        binding.btnBack.setOnClickListener { finish() }

        binding.btnAddCity.setOnClickListener {
            startActivity(Intent(this, SearchCityActivity::class.java))
        }

        setupRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun setupRecyclerView() {
        adapter = FavoritesAdapter(
            cities = emptyList(),
            onCityClick = { city ->
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_LAT, city.latitude)
                    putExtra(MainActivity.EXTRA_LON, city.longitude)
                    putExtra(MainActivity.EXTRA_CITY_NAME, city.name)
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
                finish()
            },
            onDeleteClick = { city ->
                favoritesManager.removeFavorite(city.id)
                loadFavorites()
            }
        )
        binding.rvFavoriteCities.layoutManager = LinearLayoutManager(this)
        binding.rvFavoriteCities.adapter = adapter
    }

    private fun loadFavorites() {
        val list = favoritesManager.getFavorites()
        if (list.isEmpty()) {
            binding.tvNoFavorites.visibility = View.VISIBLE
            binding.rvFavoriteCities.visibility = View.GONE
        } else {
            binding.tvNoFavorites.visibility = View.GONE
            binding.rvFavoriteCities.visibility = View.VISIBLE
            adapter.updateData(list)
        }
    }
}