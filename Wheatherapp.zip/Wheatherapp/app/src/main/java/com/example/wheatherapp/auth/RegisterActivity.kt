package com.example.wheatherapp.auth

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.wheatherapp.dashboard.MainActivity
import com.example.wheatherapp.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        binding.btnRegisterSubmit.setOnClickListener {
            registerUser()
        }

        binding.tvLoginLink.setOnClickListener {
            finish()
        }
    }

    private fun registerUser() {
        val email = binding.etRegisterEmail.text?.toString()?.trim() ?: ""
        val password = binding.etRegisterPassword.text?.toString()?.trim() ?: ""
        val confirmPassword = binding.etConfirmPassword.text?.toString()?.trim() ?: ""

        if (email.isEmpty()) {
            binding.etRegisterEmail.error = "Email is required"
            binding.etRegisterEmail.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etRegisterEmail.error = "Please enter a valid email address"
            binding.etRegisterEmail.requestFocus()
            return
        }

        if (password.isEmpty()) {
            binding.etRegisterPassword.error = "Password is required"
            binding.etRegisterPassword.requestFocus()
            return
        }

        if (password.length < 6) {
            binding.etRegisterPassword.error = "Password must be at least 6 characters"
            binding.etRegisterPassword.requestFocus()
            return
        }

        if (password != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"
            binding.etConfirmPassword.requestFocus()
            return
        }

        showLoading(true)

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                showLoading(false)
                if (task.isSuccessful) {
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                } else {
                    val errorMessage = task.exception?.localizedMessage ?: "Registration failed"
                    Toast.makeText(this, "Error: $errorMessage", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.registerProgressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.btnRegisterSubmit.isEnabled = !isLoading
    }
}