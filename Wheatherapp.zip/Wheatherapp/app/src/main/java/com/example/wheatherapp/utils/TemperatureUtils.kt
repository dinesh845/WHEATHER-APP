package com.example.wheatherapp.utils

import java.util.Locale
import kotlin.math.roundToInt

object TemperatureUtils {

    fun celsiusToFahrenheit(celsius: Double): Double {
        return (celsius * 9.0 / 5.0) + 32.0
    }

    fun formatTemperature(tempCelsius: Double, isCelsius: Boolean): String {
        return if (isCelsius) {
            "${tempCelsius.roundToInt()}°C"
        } else {
            "${celsiusToFahrenheit(tempCelsius).roundToInt()}°F"
        }
    }
}