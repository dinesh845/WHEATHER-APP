package com.example.wheatherapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.wheatherapp.R
import com.example.wheatherapp.model.FavoriteCity

class FavoritesAdapter(
    private var cities: List<FavoriteCity>,
    private val onCityClick: (FavoriteCity) -> Unit,
    private val onDeleteClick: (FavoriteCity) -> Unit
) : RecyclerView.Adapter<FavoritesAdapter.FavoriteViewHolder>() {

    class FavoriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCityName: TextView = itemView.findViewById(R.id.tvCityName)
        val tvCountry: TextView = itemView.findViewById(R.id.tvCountry)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_favorite_city, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val city = cities[position]
        holder.tvCityName.text = city.name
        holder.tvCountry.text = city.country ?: ""

        holder.itemView.setOnClickListener { onCityClick(city) }
        holder.btnDelete.setOnClickListener { onDeleteClick(city) }
    }

    override fun getItemCount(): Int = cities.size

    fun updateData(newCities: List<FavoriteCity>) {
        this.cities = newCities
        notifyDataSetChanged()
    }
}