package com.example.wheatherapp.dashboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wheatherapp.R
import com.example.wheatherapp.adapter.ForecastAdapter
import com.example.wheatherapp.auth.LoginActivity
import com.example.wheatherapp.databinding.ActivityMainBinding
import com.example.wheatherapp.favorites.FavoritesActivity
import com.example.wheatherapp.favorites.FavoritesManager
import com.example.wheatherapp.favorites.SearchCityActivity
import com.example.wheatherapp.location.LocationHelper
import com.example.wheatherapp.model.DailyForecastItem
import com.example.wheatherapp.model.FavoriteCity
import com.example.wheatherapp.model.WeatherResponse
import com.example.wheatherapp.settings.SettingsActivity
import com.example.wheatherapp.settings.SettingsManager
import com.example.wheatherapp.utils.DateUtils
import com.example.wheatherapp.utils.NetworkUtils
import com.example.wheatherapp.utils.TemperatureUtils
import com.example.wheatherapp.utils.WeatherCodeMapper
import com.example.wheatherapp.weather.WeatherRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var locationHelper: LocationHelper
    private lateinit var weatherRepository: WeatherRepository
    private lateinit var settingsManager: SettingsManager
    private lateinit var favoritesManager: FavoritesManager
    private lateinit var forecastAdapter: ForecastAdapter

    private var currentLat: Double = 0.0
    private var currentLon: Double = 0.0
    private var currentCityName: String = "Current Location"
    private var isUsingCustomLocation: Boolean = false

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            fetchCurrentLocationWeather()
        } else {
            Toast.makeText(this, "Location permission denied. Showing cached data.", Toast.LENGTH_LONG).show()
            loadCachedWeather()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        locationHelper = LocationHelper(this)
        weatherRepository = WeatherRepository(this)
        settingsManager = SettingsManager(this)
        favoritesManager = FavoritesManager(this)

        setupForecastRecyclerView()
        setupClickListeners()

        binding.tvDate.text = DateUtils.formatCurrentDate()

        handleIntentExtras(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntentExtras(intent)
    }

    override fun onResume() {
        super.onResume()
        // Re-render UI with current settings unit (°C/°F)
        val cached = weatherRepository.getCachedWeather()
        if (cached != null) {
            updateUI(cached, currentCityName)
        }
    }

    private fun handleIntentExtras(intent: Intent?) {
        if (intent != null && intent.hasExtra(EXTRA_LAT) && intent.hasExtra(EXTRA_LON)) {
            val lat = intent.getDoubleExtra(EXTRA_LAT, 0.0)
            val lon = intent.getDoubleExtra(EXTRA_LON, 0.0)
            val cityName = intent.getStringExtra(EXTRA_CITY_NAME) ?: "Selected City"

            currentLat = lat
            currentLon = lon
            currentCityName = cityName
            isUsingCustomLocation = true

            loadWeatherForCoordinates(lat, lon, cityName)
        } else {
            isUsingCustomLocation = false
            checkLocationPermissionsAndFetch()
        }
    }

    private fun setupForecastRecyclerView() {
        forecastAdapter = ForecastAdapter(emptyList(), settingsManager.isCelsius)
        binding.rv7DayForecast.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rv7DayForecast.adapter = forecastAdapter
    }

    private fun setupClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (isUsingCustomLocation) {
                loadWeatherForCoordinates(currentLat, currentLon, currentCityName)
            } else {
                fetchCurrentLocationWeather()
            }
        }

        binding.btnRefresh.setOnClickListener {
            binding.swipeRefreshLayout.isRefreshing = true
            if (isUsingCustomLocation) {
                loadWeatherForCoordinates(currentLat, currentLon, currentCityName)
            } else {
                fetchCurrentLocationWeather()
            }
        }

        binding.btnSearchCity.setOnClickListener {
            startActivity(Intent(this, SearchCityActivity::class.java))
        }

        binding.btnFavorites.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        binding.btnToggleFavorite.setOnClickListener {
            if (currentLat != 0.0 || currentLon != 0.0) {
                val isFav = favoritesManager.isFavorite(currentLat, currentLon)
                if (isFav) {
                    val favList = favoritesManager.getFavorites()
                    val target = favList.firstOrNull { Math.abs(it.latitude - currentLat) < 0.01 && Math.abs(it.longitude - currentLon) < 0.01 }
                    if (target != null) {
                        favoritesManager.removeFavorite(target.id)
                        Toast.makeText(this, "$currentCityName removed from favorites", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val favCity = FavoriteCity(
                        id = UUID.randomUUID().toString(),
                        name = currentCityName,
                        country = null,
                        latitude = currentLat,
                        longitude = currentLon
                    )
                    favoritesManager.addFavorite(favCity)
                    Toast.makeText(this, "$currentCityName added to favorites", Toast.LENGTH_SHORT).show()
                }
                updateFavoriteButtonState()
            }
        }
    }

    private fun checkLocationPermissionsAndFetch() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            fetchCurrentLocationWeather()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun fetchCurrentLocationWeather() {
        if (!NetworkUtils.isNetworkAvailable(this)) {
            binding.swipeRefreshLayout.isRefreshing = false
            Toast.makeText(this, "No internet connection. Showing cached weather.", Toast.LENGTH_SHORT).show()
            loadCachedWeather()
            return
        }

        binding.swipeRefreshLayout.isRefreshing = true

        lifecycleScope.launch {
            val location = locationHelper.getCurrentLocation()
            if (location != null) {
                currentLat = location.latitude
                currentLon = location.longitude
                currentCityName = locationHelper.getCityName(currentLat, currentLon)
                loadWeatherForCoordinates(currentLat, currentLon, currentCityName)
            } else {
                // Fallback default coordinates if GPS is disabled or unavailable on emulator
                currentLat = 51.5074
                currentLon = -0.1278
                currentCityName = "London"
                loadWeatherForCoordinates(currentLat, currentLon, currentCityName)
            }
        }
    }

    private fun loadWeatherForCoordinates(lat: Double, lon: Double, cityName: String) {
        currentLat = lat
        currentLon = lon
        currentCityName = cityName

        if (!NetworkUtils.isNetworkAvailable(this)) {
            binding.swipeRefreshLayout.isRefreshing = false
            Toast.makeText(this, "No internet connection. Showing cached weather.", Toast.LENGTH_SHORT).show()
            loadCachedWeather()
            return
        }

        binding.swipeRefreshLayout.isRefreshing = true

        lifecycleScope.launch {
            try {
                val weather = weatherRepository.fetchWeather(lat, lon)
                weatherRepository.saveCachedCityName(cityName)
                binding.cardOffline.visibility = View.GONE
                updateUI(weather, cityName)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Failed to load weather: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                loadCachedWeather()
            } finally {
                binding.swipeRefreshLayout.isRefreshing = false
            }
        }
    }

    private fun loadCachedWeather() {
        binding.swipeRefreshLayout.isRefreshing = false
        val cached = weatherRepository.getCachedWeather()
        val cachedCity = weatherRepository.getCachedCityName()

        if (cached != null) {
            binding.cardOffline.visibility = View.VISIBLE
            updateUI(cached, cachedCity)
        } else {
            binding.tvCityName.text = "No Weather Data"
            binding.tvCurrentTemp.text = "--"
            binding.tvWeatherCondition.text = "Connect to Internet"
            binding.cardOffline.visibility = View.VISIBLE
        }
    }

    private fun updateUI(weather: WeatherResponse, cityName: String) {
        val isCelsius = settingsManager.isCelsius

        binding.tvCityName.text = cityName

        val current = weather.current
        if (current != null) {
            binding.tvCurrentTemp.text = TemperatureUtils.formatTemperature(current.temperature2m, isCelsius)
            binding.tvWindSpeed.text = "${current.windSpeed10m} km/h"

            val (conditionText, iconRes) = WeatherCodeMapper.mapWeatherCode(current.weatherCode)
            binding.tvWeatherCondition.text = conditionText
            binding.ivCurrentIcon.setImageResource(iconRes)
        }

        val daily = weather.daily
        if (daily != null && !daily.time.isNullOrEmpty()) {
            val maxTemps = daily.temperature2mMax ?: emptyList()
            val minTemps = daily.temperature2mMin ?: emptyList()
            val codes = daily.weatherCode ?: emptyList()

            if (maxTemps.isNotEmpty()) {
                binding.tvMaxTemp.text = TemperatureUtils.formatTemperature(maxTemps[0], isCelsius)
            }
            if (minTemps.isNotEmpty()) {
                binding.tvMinTemp.text = TemperatureUtils.formatTemperature(minTemps[0], isCelsius)
            }

            val forecastItems = mutableListOf<DailyForecastItem>()
            val count = minOf(7, daily.time.size)

            for (i in 0 until count) {
                val dateStr = daily.time[i]
                val dayName = DateUtils.formatDayName(dateStr)
                val maxC = if (i < maxTemps.size) maxTemps[i] else 0.0
                val minC = if (i < minTemps.size) minTemps[i] else 0.0
                val code = if (i < codes.size) codes[i] else (current?.weatherCode ?: 0)
                val (cond, icon) = WeatherCodeMapper.mapWeatherCode(code)

                forecastItems.add(
                    DailyForecastItem(
                        dayName = dayName,
                        dateString = dateStr,
                        maxTempC = maxC,
                        minTempC = minC,
                        weatherCode = code,
                        conditionDescription = cond,
                        iconResId = icon
                    )
                )
            }

            forecastAdapter.updateData(forecastItems, isCelsius)
        }

        updateFavoriteButtonState()
    }

    private fun updateFavoriteButtonState() {
        val isFav = favoritesManager.isFavorite(currentLat, currentLon)
        if (isFav) {
            binding.btnToggleFavorite.setImageResource(R.drawable.ic_favorite)
        } else {
            binding.btnToggleFavorite.setImageResource(R.drawable.ic_favorite_border)
        }
    }

    companion object {
        const val EXTRA_LAT = "extra_latitude"
        const val EXTRA_LON = "extra_longitude"
        const val EXTRA_CITY_NAME = "extra_city_name"
    }
}