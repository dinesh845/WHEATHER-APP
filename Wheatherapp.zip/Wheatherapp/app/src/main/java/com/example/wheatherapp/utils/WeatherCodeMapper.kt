package com.example.wheatherapp.utils

import com.example.wheatherapp.R

object WeatherCodeMapper {

    fun mapWeatherCode(code: Int): Pair<String, Int> {
        return when (code) {
            0 -> Pair("Clear Sky", R.drawable.ic_weather_clear)
            1 -> Pair("Mainly Clear", R.drawable.ic_weather_partly_cloudy)
            2 -> Pair("Partly Cloudy", R.drawable.ic_weather_partly_cloudy)
            3 -> Pair("Overcast", R.drawable.ic_weather_cloudy)
            45, 48 -> Pair("Fog", R.drawable.ic_weather_fog)
            51, 53, 55 -> Pair("Drizzle", R.drawable.ic_weather_drizzle)
            56, 57 -> Pair("Freezing Drizzle", R.drawable.ic_weather_drizzle)
            61, 63, 65 -> Pair("Rain", R.drawable.ic_weather_rain)
            66, 67 -> Pair("Freezing Rain", R.drawable.ic_weather_rain)
            71, 73, 75, 77 -> Pair("Snowfall", R.drawable.ic_weather_snow)
            80, 81, 82 -> Pair("Rain Showers", R.drawable.ic_weather_rain)
            85, 86 -> Pair("Snow Showers", R.drawable.ic_weather_snow)
            95, 96, 99 -> Pair("Thunderstorm", R.drawable.ic_weather_thunder)
            else -> Pair("Clear", R.drawable.ic_weather_clear)
        }
    }
}